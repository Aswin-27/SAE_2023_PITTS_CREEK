# Object_detection_target > 2024-06-21 9:31am
https://universe.roboflow.com/kathiravan-matric-higher-secondary-school/object_detection_target

Provided by a Roboflow user
License: CC BY 4.0

